require('./2-set');

console.log(answer);
