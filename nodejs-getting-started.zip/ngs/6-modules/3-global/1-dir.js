console.dir(global, { depth: 0 });
