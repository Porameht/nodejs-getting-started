global.answer = 42;
