const myTemplate = require('./3-string');

console.log(myTemplate);
