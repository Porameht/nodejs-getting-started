const api = require('./1-object');

console.log(api.language, api.direction, api.encoding);
